package com.example.recyclerviewvolleyglide.model;

public class Anime {

    private String name;
    private String brand;
    private String imageURL;
    private double price;

    public Anime(){

    }

    public Anime(String name, String brand, String imageURL, double price) {
        this.name = name;
        this.brand = brand;
        this.imageURL = imageURL;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
